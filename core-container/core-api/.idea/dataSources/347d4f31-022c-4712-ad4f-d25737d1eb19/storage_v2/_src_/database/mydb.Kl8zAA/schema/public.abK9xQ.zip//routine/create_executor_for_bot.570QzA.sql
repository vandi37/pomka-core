create function create_executor_for_bot() returns trigger
    language plpgsql
as
$$
begin
    insert into executors(bot, executor_type)
    values (NEW.id, 'bot');
    return NEW;
end ;
$$;

alter function create_executor_for_bot() owner to myuser;

