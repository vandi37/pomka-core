create function create_executor_for_userbot() returns trigger
    language plpgsql
as
$$
begin
    insert into executors(userbot, executor_type)
    values (NEW.id, 'userbot');
    return NEW;
end ;
$$;

alter function create_executor_for_userbot() owner to myuser;

