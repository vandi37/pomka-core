create function create_executor_for_admin() returns trigger
    language plpgsql
as
$$
begin
    insert into executors(admin, executor_type)
    values (NEW.id, 'admin');
    return NEW;
end;
$$;

alter function create_executor_for_admin() owner to myuser;

